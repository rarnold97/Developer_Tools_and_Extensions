# AHK for Notepad++

Syntax highlighting for AutoHotKey in Notepad++

Currently supported themes:
- Dracula (https://draculatheme.com/notepad-plus-plus/)
- Lunar (https://forum.facepunch.com/f/gmoddev/myjf/Lunar-a-sleek-and-beautiful-theme-for-notepad/1/) [[[BROKEN LINK]]]


Want your theme to be supported? Just create new issue and I'll try to make it work...

Be sure to include:
- the theme name
- the website to the theme, or just paste XML
